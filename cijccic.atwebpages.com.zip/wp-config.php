<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/srv/disk13/3717091/www/cijccic.atwebpages.com/wp-content/plugins/wp-super-cache/' );
define( 'DB_NAME', '3717091_wpressf05b5a7e' );

/** MySQL database username */
define( 'DB_USER', '3717091_wpressf05b5a7e' );

/** MySQL database password */
define( 'DB_PASSWORD', 'VWUl8wwSYvJgCJIKBQrIOkF4skeAMBMj' );

/** MySQL hostname */
define( 'DB_HOST', 'fdb30.runhosting.com' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'F[O~^&tt]Q3jnQVZRY0If$S]xU?&A;!(a4&YWzb6@c6i@jd0@8`(>kk]~?0%-RZa' );
define( 'SECURE_AUTH_KEY',  '~XmL&t@c87j#bzNXhv!UNp#I<GAy2C`U2,8/-<g4k}9KcoyW37nh~!lI3>{18[jq' );
define( 'LOGGED_IN_KEY',    ' $FR3X!|H-I2/C,(Mg>U$?{=;#Lq>BV*dg%p1[N{=:/|iSVRN&-&_d%J908$6T-7' );
define( 'NONCE_KEY',        ' RA-v<X+t0<0@qeJ}]+nOAnIwvCtsk6plxf$#^a0ztHnC+g`,P{.uoJfUic<UL9x' );
define( 'AUTH_SALT',        'O(I Z!wm]B<A$}pMK]Hy(}eqi=JaX[?/je%4Q? `rz=Rxpr&X:uP{si{J6uz0fT%' );
define( 'SECURE_AUTH_SALT', 'rkI6(lrFk#zm[@OkU.cR9M5[vL0HuW79(/SaH}C^f<sSM :9pSc8{S,d]j{1Atwo' );
define( 'LOGGED_IN_SALT',   '_vdr*>T2=yOHXwJ`#Ggm-NS|U}gp5QE.x@8z[GFpiGN]RpOe(O%8.6/N[)p)dyY+' );
define( 'NONCE_SALT',       '$1jo`YUV@%0V_)|pb-$,EbH{sb-SYFk1b:aa)ul9VL~:K&@zk0$K/GU]e_p$X&44' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
