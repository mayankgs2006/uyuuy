<?php /*

This file contains internal information for the Zacky Installer.
Do NOT change. Removing it might prevent you from using the installer 
on this installation in the future.

---
QlpoOTFBWSZTWfakCNsAAJlfgEAQQId/8CHwDRC/79+7MAE5rGhqmJkNE8p7UENMgABoYm1BqaTU
emJPU/VPKBhA0AeoANBqeppNNRgEZBiBoAGQaF+Z2twBuapymgC593yx7iQ8A4krJVRRlryMfCqa
JuBGYFBMzvfcZm1CGVBHFVNU8JQLX5HMCTzlAghXYMQb0fM9lLkXUASdSINaQespWhmSJYDEXUAg
1075XmZnRSCFhDUpgXtr2OFaiokFcAz9N96AcmyoHIpcfbCK24e3yLATBsEVF14p59LYCzGOJ5e0
PBOK1MsctJDCsCfO6WmkpMg0FyaUM9WRrKmTHinJK0qMGO+rBMOgIQC7nAmbMAZ+mtdqnmyjiOzF
6QJnJoZsx3IGsFG1oNJqPUpOBgqpzb81gxLzoXDWmBRYwgsKUlh3WVTnWZzJMqxjSi2V/8XckU4U
JD2pAjbA

...

*/
